"use client";
const Education = () => {
  return (
    <div className="education-page">
      <h2>Education</h2>
      <h3>Oakland University</h3>
      <p>Bachelor’s in Cyber Security, Rochester, MI | 06/2023-Expected 04/2025</p>
      <p>GPA: 3.66</p>
      <p>Part of Cyber OU</p>
      <p>Relevant Coursework: Cloud Computing, Data Structures and Algorithms, Fundamentals of Cybersecurity</p>
    </div>
  );
};

export default Education;

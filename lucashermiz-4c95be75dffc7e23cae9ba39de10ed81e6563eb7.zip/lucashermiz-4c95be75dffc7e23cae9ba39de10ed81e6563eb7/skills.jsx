"use client";
const Skills = () => {
  return (
    <div className="skills-page">
      <h2>Skills</h2>
      <h3>Programming Languages</h3>
      <p>Python, PowerShell, Java, C++, HTML, SQL, Teach Pendant, Karel</p>
      <h3>Computer Science</h3>
      <p>
        Wireshark, Nmap, Cryptography, Risk Management, Cloud Security, Network
        Security, Security Auditing, Security Architecture, Linux
      </p>
      <h3>Soft Skills</h3>
      <p>Fast Learner, Problem-Solving, Teamwork, Analytical Thinking, Communication</p>
    </div>
  );
};

export default Skills;
